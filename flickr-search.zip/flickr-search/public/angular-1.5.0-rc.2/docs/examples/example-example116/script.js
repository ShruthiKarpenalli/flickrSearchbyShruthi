(function(angular) {
  'use strict';
angular.module('ngSwipeLeftExample', ['ngTouch']);
})(window.angular);